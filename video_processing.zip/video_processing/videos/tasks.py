import os
from celery import shared_task
from .models import Video, Subtitle

@shared_task
def process_video(video_id):
    video = Video.objects.get(id=video_id)
    video_path = video.video_file.path
    
    # Use ccextractor to extract subtitles
    os.system(f'ccextractor {video_path}')
    
    # Here, we're assuming subtitles are extracted to a file `video.srt`
    # Add logic to parse the file and save it to the database
    with open('video.srt', 'r') as subtitle_file:
        content = subtitle_file.read()
        Subtitle.objects.create(video=video, language='English', content=content)
    
    video.processed = True
    video.save()
