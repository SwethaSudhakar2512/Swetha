from django.shortcuts import render, redirect
from .models import Video
from .tasks import process_video

def upload_video(request):
    if request.method == 'POST':
        video_file = request.FILES['video_file']
        video = Video.objects.create(video_file=video_file)
        process_video.delay(video.id)  # Background task
        return redirect('video_list')
    return render(request, 'upload.html')
from django.shortcuts import render
from .models import Subtitle

def search_subtitles(request):
    if 'query' in request.GET:
        query = request.GET['query']
        subtitles = Subtitle.objects.filter(content__icontains=query)
        return render(request, 'search_results.html', {'subtitles': subtitles})
    return render(request, 'search.html')
from .models import Video

def video_list(request):
    videos = Video.objects.all()
    return render(request, 'video_list.html', {'videos': videos})
