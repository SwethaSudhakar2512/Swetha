from django.shortcuts import render, get_object_or_404, redirect
from .models import Study
from .forms import StudyForm
import logging

logger = logging.getLogger(__name__)

def study_list(request):
    studies = Study.objects.all()
    return render(request,'studies/study_list.html', {'studies': studies})

def study_detail(request, pk):
    study = get_object_or_404(Study, pk=pk)
    return render(request,'studies/study_detail.html', {'study': study})

def study_create(request):
    if request.method == 'POST':
        form = StudyForm(request.POST)
        if form.is_valid():
            try:
                form.save()
                return redirect('study_list')
            except Exception as e:
                logger.error(f"Error saving study: {e}")
    else:
        form = StudyForm()
    return render(request,'studies/study_form.html', {'form': form})

def study_update(request, pk):
    study = get_object_or_404(Study, pk=pk)
    if request.method == 'POST':
        form = StudyForm(request.POST, instance=study)
        if form.is_valid():
            try:
                form.save()
                return redirect('study_list')
            except Exception as e:
                logger.error(f"Error updating study: {e}")
    else:
        form = StudyForm(instance=study)
    return render(request, 'studies/study_form.html', {'form': form})

def study_delete(request, pk):
    study = get_object_or_404(Study, pk=pk)
    try:
        study.delete()
    except Exception as e:
        logger.error(f"Error deleting study: {e}")
    return redirect('study_list')

