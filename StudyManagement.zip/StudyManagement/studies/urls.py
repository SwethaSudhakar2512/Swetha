
from django.urls import path
from . import views

urlpatterns = [
    path('', views.study_list, name='study_list'),  
    path('<int:pk>/', views.study_detail, name='study_detail'),
    path('new/', views.study_create, name='study_create'),
    path('<int:pk>/edit/', views.study_update, name='study_update'),
    path('<int:pk>/delete/', views.study_delete, name='study_delete'),
]

